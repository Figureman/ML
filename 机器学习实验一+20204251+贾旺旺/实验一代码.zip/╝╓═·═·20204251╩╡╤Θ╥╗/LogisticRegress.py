import numpy as np
import matplotlib.pyplot as plt
from math import *
class LogisticsRegression():
    def __init__(self):
        '''
        初始化逻辑回归模型
        θ向量
        '''
        self.theta=None
        self.lossList=[]

    #定义sigmoid函数
    def sigmoid(self,x):
        '''
        :param x:
        :return:
        '''
        return 1.0/(1.0+np.exp(-x))

    #使用批量梯度下降法，不断更新参数
    def BGD(self,x,y,eta=0.01):
        '''
        :param x:训练数据集
        :param y: 标签集
        :param eta: 学习率
        :return: 学习参数和Loss
        '''
        self.theta=np.zeros(x.shape[1], dtype=float)
        iter_count=7000
        for i in range(iter_count):
            gred=(self.sigmoid(x.dot(self.theta))-y).dot(x)
            self.lossList.append(self.loss(x,y))
            self.theta=self.theta-eta*gred
    def loss(self,x,y):
        y1=self.sigmoid(x.dot(self.theta))
        loss_1=0.0
        for i in range(len(y1)):
            loss_1=loss_1+(-y[i]*log2(y1[i])+(y[i]-1)*log2(1-y1[i]))
        loss_1=loss_1/len(y1)
        return loss_1
    def predictW(self,x):
        '''
        :param x:
        :return:
        '''
        a=self.sigmoid(x.dot(self.theta))
        return np.array(a>=0.5,dtype='int')
    def predictI(self,x):
        '''
        :param x:
        :return:
        '''
        a = self.sigmoid(x.dot(self.theta))
        return a
    #西瓜集使用作图
    #求准确率
    def scoreW(self,label, x):
        '''
        :param label: 测试集标签数据，类型为ndarray
        :param x    : 测试集数据
        :param predict: 预测标签数据，类型为ndarray
        '''
        print(type(x))
        List=self.predictW(x)
        x1, y1 = [], []  #TT:实际好瓜，预测好瓜
        x2, y2 = [], []  #TF:实际好瓜，预测坏瓜
        x3, y3 = [], []  #FT:实际坏瓜，预测好瓜
        x4, y4 = [], []  #FF:实际坏瓜，预测坏瓜
        '''
        :param T_T:实际是1，预测也是1。以下类似处理
        '''
        T_T,T_F=0,0
        F_T,F_F=0,0
        for i in range(len(label)):
            if(label[i]==List[i]):
                if(label[i]==1):
                    T_T+=1
                    x1.append(x[i][1])
                    y1.append(x[i][2])
                else:
                    F_F+=1
                    x4.append(x[i][1])
                    y4.append(x[i][2])

            else:
                if(label[i]==1):
                    T_F+=1
                    x2.append(x[i][1])
                    y2.append(x[i][2])
                else:
                    F_T+=1
                    x3.append(x[i][1])
                    y3.append(x[i][2])

        plt.scatter(x1, y1, c="green", marker="*", label='TP')  # 实际：好瓜 预测：好瓜 (*预测正确)
        plt.scatter(x4, y4, c="green", marker="x", label='FN')  # 实际：好瓜 预测：坏瓜 (x预测错误)
        plt.scatter(x3, y3, c="blue", marker="*", label='TN')  # 实际：坏瓜 预测：坏瓜
        plt.scatter(x2, y2, c="blue", marker="x", label='FP')  # 实际：坏瓜 预测：好瓜
        plt.legend()
        x = np.linspace(-2, 2, 100)
        y = -(self.theta[1] * x + self.theta[0]) / self.theta[2]
        plt.plot(x, y, color="red")
        plt.xlabel('density')
        plt.ylabel('sugar_content')
        plt.show()
        n=T_T+T_F+F_T+F_F
        accuracy = (T_T + F_F) / n  # 准确率
        error_rate = (T_F + F_T) / n  # 错误率
        precision = T_T / (T_T + F_T)  # 精确率
        recall = T_T / (T_T + T_F)  # 召回率
        print("TP=", T_T, "FP=", F_T, "FN=", T_F, "TN=", F_F)
        print("准确率=", accuracy, "错误率=", error_rate, "精确率=", precision, "召回率=", recall)
        print("模型为：", self.theta[1], "* x1 +", self.theta[2], "* x2 +", self.theta[0])
    #损失函数图像
    def drawLoss(self):
        len1=len(self.lossList)
        x=[i for i in range(len1)]
        plt.scatter(x, self.lossList, c="blue", marker="x", label='FP')
        plt.show()

# 求准确率
def score(label, predict):
    '''
    :param label: 测试集标签数据，类型为ndarray
    :param predict: 预测标签数据，类型为ndarray
    '''
    label=label.astype(np.int)                  #将label转换为numpy.int类型
    return np.mean(label == predict)